const home = "https://performancemanager10.successfactors.com/sf/start/";
const timer = "refresh-successfactors";
let running;

async function refresh() {
  const tabs = await chrome.tabs.query({url: "https://performancemanager10.successfactors.com/sf/*"});
  const match = tabs.find(tab => tab.url && ["/sf/start", "/sf/home"].includes(new URL(tab.url).pathname.replace(/\/$/, "")));
  if (match) {
    await chrome.storage.session.set({tracked: match.id});
    await chrome.tabs.reload(match.id);
    console.info("SuccessFactors tab reload requested", new Date().toISOString());
    return;
  }

  const {tracked} = await chrome.storage.session.get("tracked");
  if (tracked !== undefined) {
    const previous = await chrome.tabs.get(tracked).catch(() => undefined);
    // A redirect to a sign-in provider can hide the URL from this extension.
    // Leave that tab available for sign-in without opening another copy.
    if (previous && !previous.url) return;
  }
  const tab = await chrome.tabs.create({url: home, active: false});
  await chrome.storage.session.set({tracked: tab.id});
}

function run() {
  if (!running) running = refresh().finally(() => { running = undefined; });
  return running;
}

async function start() {
  await chrome.alarms.create(timer, {periodInMinutes: 5});
  await run();
}

chrome.runtime.onInstalled.addListener(start);
chrome.runtime.onStartup.addListener(start);
chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === timer) return run();
});

